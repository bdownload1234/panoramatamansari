	<footer class="main-footer text-center">
	    <strong>Copyright &copy; <strong>Admin Web</strong>
	</footer>


</div>
<script src="<?=base_url('theme_admin/plugins/jquery/jquery.min.js');?>"></script> 
<script src="<?=base_url('theme_admin/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
<script src="<?=base_url('theme_admin/dist/js/adminlte.min.js');?>"></script>
<script src="<?=base_url('theme_admin/dist/js/Lobibox.js');?>"></script>
<script src="<?=base_url('theme_admin/dist/js/jquery-confirm.min.js'); ?>"></script>
<script src="<?=base_url('theme_admin/plugins/datatables/jquery.dataTables.min.js')?>"></script>
<script src="<?=base_url('theme_admin/plugins/datepicker/bootstrap-datepicker.js')?>"></script>

