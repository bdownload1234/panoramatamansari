<table border="1">
        <tr>
            <th>No</th>
            <th>Kode Kavling</th>
            <th>Luas Tanah</th>
            <th>Tipe Bangunan</th>
            <th>Harga Jual</th>
            <th>Harga Diskon</th>
            <th>Nama Cuntomer</th>
            <th>Nama Marketing</th>
            <th>Status Kavling</th>
            <th>Keterangan</th>
        </tr>

        <?php 
        $no =1;
        foreach ($downData as $dt) {
            echo '<tr>
            <td>'.$no++.'</td>
            <td>'.$dt->kode_kavling.'</td>
            <td>'.$dt->luas_tanah.'</td>
            <td>'.$dt->tipe_bangunan.'</td>
            <td>'.$dt->hrg_jual.'</td>
            <td>'.$dt->harga_diskon.'</td>
            <td>'.$dt->nama_lengkap.'</td>
            <td>'.$dt->nama_marketing.'</td>
            <td>'.$dt->stt_kavling.'</td>
            <td>'.$dt->keterangan.'</td>
        </tr>';
        }
        ?>

</table>
