<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

        <div class="container">
<br>
<section class="content">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Form Registrasi</h4>
        </div>

        <!-- /.card-header -->
        <div class="card-body">
            <center>
                <b>PANORAMA TAMANSARI</b>
                <br>
                <br>
                Resistrasi Gagal. silahkan hubungi admin.
                <br> 
                <br> 
                <br>
                <b>ADMIN PANORAMA TAMANSARI</b> 
            </center>
            
        </div>
      </div>
</section>
        </div>


</body>
</html>
